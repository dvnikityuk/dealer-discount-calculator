import { NextRequest, NextResponse } from "next/server";
import * as XLSX from "xlsx";
import { readState } from "@/lib/data-store";
import {
  fmt,
  fmtPct,
  quarterlyFactsByCategory,
  quarterlyPlan,
  serviceFactAccumulated,
  servicePlan,
} from "@/lib/calc";
import {
  calcEquipmentDiscountPct,
  calcMaterialsDiscountPct,
  calcServiceDiscountAmount,
  getServiceDiscountPctNormalized,
} from "@/lib/discount";
import type { Quarter } from "@/lib/types";

export async function GET(req: NextRequest) {
  const state = await readState();
  const quarter = (Number(req.nextUrl.searchParams.get("q") ?? state.quarter) || 1) as Quarter;
  const q = quarter;

  const wb = XLSX.utils.book_new();

  // --- Sheet 1: Сводная ---
  const summaryRows: (string | number)[][] = [];
  summaryRows.push([
    "Дилер", "Тип", "План", "Факт", "Вып.",
    "Оборуд. (план)", "Оборуд. (факт)",
    "Расх. мат. (план)", "Расх. мат. (факт)",
    "Оборуд. %", "Расход. мат. %",
  ]);
  for (const d of state.dealers) {
    const plan = quarterlyPlan(d, q);
    const facts = quarterlyFactsByCategory(d, q);
    const factTotal =
      facts.service !== null || facts.equipment !== null || facts.materials !== null
        ? (facts.service ?? 0) + (facts.equipment ?? 0) + (facts.materials ?? 0)
        : null;
    const eqPlan = d.type === "Заруб" ? d.plan.equipment / 2 : d.plan.equipment / 4;
    const matPlan = d.type === "Заруб" ? d.plan.materials / 2 : d.plan.materials / 4;
    // Dynamic discounts based on scale tables
    const eqPct = calcEquipmentDiscountPct(d, q);
    const matPct = calcMaterialsDiscountPct(d, q);
    summaryRows.push([
      d.name,
      d.type,
      `${fmt(plan)}/${d.type === "Заруб" ? "пг" : "кв"}`,
      factTotal === null ? "нет данных" : `${fmt(factTotal)}/${d.type === "Заруб" ? "пг" : "кв"}`,
      factTotal === null ? "—" : `${Math.round((factTotal / plan) * 100)}%`,
      fmt(Math.round(eqPlan), " €"),
      fmt(facts.equipment, " €"),
      fmt(Math.round(matPlan), " €"),
      fmt(facts.materials, " €"),
      eqPct === null ? "—" : fmtPct(eqPct),
      matPct === null ? "—" : fmtPct(matPct),
    ]);
  }
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(summaryRows), "Сводная");

  // --- Sheet 2: Сервис ---
  const serviceRows: (string | number)[][] = [];
  serviceRows.push([
    "Дилер", "Тип", "План Сервис (год)", "Факт Сервис (накопл.)",
    "Выполн. Сервис", "Сервис %", "Сервис скидка €",
  ]);
  for (const d of state.dealers) {
    const sp = servicePlan(d);
    const sf = serviceFactAccumulated(d);
    const exec = sf === null ? "—" : sp === 0 ? "—" : `${Math.round((sf / sp) * 100)}%`;
    const pct = getServiceDiscountPctNormalized(d);
    const discount = calcServiceDiscountAmount(d);
    serviceRows.push([
      d.name, d.type, fmt(sp),
      sf === null ? "нет данных" : fmt(sf),
      exec,
      pct === null ? "—" : fmtPct(pct),
      discount === null ? "—" : fmt(discount, " €"),
    ]);
  }
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(serviceRows), "Сервис");

  // --- Sheet 3: Данные ---
  const dataRows: (string | number)[][] = [];
  dataRows.push([
    "Дилер", "Тип",
    "План Сервис (год)", "План Оборуд. (год)", "План Расход. мат. (год)",
    "Итого план", "В мес.",
  ]);
  for (const d of state.dealers) {
    const total = d.plan.service + d.plan.equipment + d.plan.materials;
    dataRows.push([
      d.name, d.type,
      fmt(d.plan.service), fmt(d.plan.equipment), fmt(d.plan.materials),
      fmt(total), fmt(Math.round(total / 12)),
    ]);
  }
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(dataRows), "Данные");

  // --- Sheet 4: Шкалы ---
  const scaleRows: (string | number)[][] = [];
  for (const table of state.scales) {
    scaleRows.push([table.title]);
    scaleRows.push(["Компонент", ...table.columns]);
    for (const row of table.rows) scaleRows.push([row.component, ...row.values]);
    scaleRows.push([]);
  }
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(scaleRows), "Шкалы");

  const buf = XLSX.write(wb, { type: "buffer", bookType: "xlsx" }) as ArrayBuffer;
  return new NextResponse(buf, {
    status: 200,
    headers: {
      "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "Content-Disposition": `attachment; filename="discounts-q${quarter}.xlsx"`,
      "Cache-Control": "no-store, no-cache, must-revalidate",
    },
  });
}
