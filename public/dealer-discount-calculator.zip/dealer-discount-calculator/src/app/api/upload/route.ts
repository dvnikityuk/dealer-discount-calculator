import { NextRequest, NextResponse } from "next/server";
import { saveUploadedFiles } from "@/lib/data-store";

/**
 * POST /api/upload
 * Accept multipart/form-data with two optional files:
 *   - facts: CSV file (Выполнение условий.csv)
 *   - plans: XLSX file (Условия работы ТПС 2026.xlsx)
 *
 * Saves files to data/uploads/, re-parses them, rebuilds state, and
 * invalidates the page cache so F5 picks up the new data.
 */
export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData();
    const factsFile = formData.get("facts");
    const plansFile = formData.get("plans");

    if (!factsFile && !plansFile) {
      return NextResponse.json(
        { ok: false, error: "Не передано ни одного файла. Ожидается 'facts' (CSV) и/или 'plans' (XLSX)." },
        { status: 400 },
      );
    }

    let factsCsv: string | null = null;
    let plansXlsx: Buffer | null = null;

    if (factsFile && factsFile instanceof File) {
      factsCsv = await factsFile.text();
    }
    if (plansFile && plansFile instanceof File) {
      const ab = await plansFile.arrayBuffer();
      plansXlsx = Buffer.from(ab);
    }

    const state = await saveUploadedFiles(factsCsv, plansXlsx);

    return NextResponse.json({
      ok: true,
      lastSync: state.lastSync,
      dealerCount: state.dealers.length,
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    console.error("[/api/upload] Error:", err);
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ ok: false, error: message }, { status: 500 });
  }
}
