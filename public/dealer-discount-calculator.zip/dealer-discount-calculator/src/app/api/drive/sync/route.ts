import { NextResponse } from "next/server";
import { syncFromDisk } from "@/lib/data-store";

/**
 * POST /api/drive/sync
 *
 * Re-reads state.json from disk, clears the in-memory cache, and invalidates
 * the page cache via revalidatePath("/"). After this call, F5 / hard refresh
 * will see the latest data on disk.
 *
 * This is the explicit "force reload from disk" endpoint that the "Диск" button
 * invokes from the UI.
 */
export async function POST() {
  const state = await syncFromDisk();
  return NextResponse.json({
    ok: true,
    lastSync: state.lastSync,
    dealerCount: state.dealers.length,
    timestamp: new Date().toISOString(),
  });
}

export async function GET() {
  const state = await syncFromDisk();
  return NextResponse.json({
    ok: true,
    lastSync: state.lastSync,
    dealerCount: state.dealers.length,
    timestamp: new Date().toISOString(),
  });
}
