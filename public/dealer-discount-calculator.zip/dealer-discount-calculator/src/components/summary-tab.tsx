"use client";

import type { DealerData, Quarter } from "@/lib/types";
import {
  fmt, fmtPct, quarterlyPlan, quarterlyFactsByCategory,
  servicePlan, serviceFactAccumulated, hasFacts,
} from "@/lib/calc";
import {
  calcEquipmentDiscountPct, calcMaterialsDiscountPct,
  getServiceDiscountPctNormalized,
} from "@/lib/discount";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Tooltip, TooltipContent, TooltipProvider, TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Building2, Euro, Percent, TrendingUp,
  Info, Printer, TrendingDown,
} from "lucide-react";
import { printDealer } from "@/components/dealer-print-view";

/** Scrollable table container — supports BOTH horizontal and vertical scroll, with sticky header row and sticky first column. */
function ScrollableTable({
  children,
  maxHeight = "70vh",
  firstColWidth = "180px",
}: {
  children: React.ReactNode;
  maxHeight?: string;
  firstColWidth?: string;
}) {
  return (
    <div
      className="w-full overflow-auto thin-scroll print:overflow-visible"
      style={{ maxHeight, WebkitOverflowScrolling: "touch" }}
    >
      <style>{`
        .thin-scroll::-webkit-scrollbar { width: 10px; height: 10px; }
        .thin-scroll::-webkit-scrollbar-track { background: #f1f5f9; }
        .thin-scroll::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 4px; }
        .thin-scroll::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
        .thin-scroll * { scrollbar-width: thin; scrollbar-color: #cbd5e1 #f1f5f9; }
        @media print {
          .no-print { display: none !important; }
          .print-block { display: block !important; }
          .thin-scroll { max-height: none !important; overflow: visible !important; }
        }
      `}</style>
      <div style={{ minWidth: firstColWidth }}>
        <Table>{children}</Table>
      </div>
    </div>
  );
}

interface Props {
  dealers: DealerData[];
  quarter: Quarter;
  kpis: {
    rfCount: number;
    foreignCount: number;
    planTotal: number;
    factTotal: number;
    dealersWithFacts: number;
    avgExec: number;
  };
  quarterMonthRange: string;
  halfYearMonthRange: string;
}

export function SummaryTab({
  dealers, quarter, kpis, quarterMonthRange, halfYearMonthRange,
}: Props) {
  const periodSuffix = (d: DealerData) => (d.type === "Заруб" ? "пг" : "кв");

  const handlePrint = () => window.print();
  const handleDealerPrint = (d: DealerData) =>
    printDealer({ dealer: d, quarter, quarterMonthRange });

  return (
    <TooltipProvider delayDuration={200}>
      <div className="space-y-4">
        {/* ─── KPI cards ──────────────────────────────────────────────────── */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-gray-500 font-medium">Дилеров</span>
                <div className="w-7 h-7 rounded-md flex items-center justify-center bg-emerald-100 text-emerald-600">
                  <Building2 className="w-4 h-4" />
                </div>
              </div>
              <div className="text-lg font-bold text-emerald-700">{dealers.length}</div>
              <p className="text-xs text-gray-400 mt-0.5">{kpis.rfCount} РФ / {kpis.foreignCount} заруб.</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-gray-500 font-medium">План {quarter} кв. ({quarterMonthRange})</span>
                <div className="w-7 h-7 rounded-md flex items-center justify-center bg-sky-100 text-sky-600">
                  <Euro className="w-4 h-4" />
                </div>
              </div>
              <div className="text-lg font-bold text-sky-700">{fmt(kpis.planTotal)}</div>
              <p className="text-xs text-gray-400 mt-0.5">итого все дилеры</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-gray-500 font-medium">Факт {quarter} кв. ({quarterMonthRange})</span>
                <div className="w-7 h-7 rounded-md flex items-center justify-center bg-amber-100 text-amber-600">
                  <Percent className="w-4 h-4" />
                </div>
              </div>
              <div className="text-lg font-bold text-amber-700">{fmt(kpis.factTotal)}</div>
              <p className="text-xs text-gray-400 mt-0.5">{kpis.dealersWithFacts} из {dealers.length} с данными</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-gray-500 font-medium">Ср. выполнение</span>
                <div className="w-7 h-7 rounded-md flex items-center justify-center bg-rose-100 text-rose-600">
                  {kpis.avgExec >= 70 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                </div>
              </div>
              <div className="text-lg font-bold text-rose-700">{kpis.avgExec.toFixed(1)}%</div>
              <p className="text-xs text-gray-400 mt-0.5">за {quarter} кв. ({quarterMonthRange})</p>
            </CardContent>
          </Card>
        </div>

        {/* ─── Table 1: Volume + execution + discounts ────────────────────── */}
        <Card className="overflow-hidden">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <CardTitle className="font-semibold text-base">Сводная таблица выполнения условий</CardTitle>
              <Tooltip>
                <TooltipTrigger asChild>
                  <button type="button" className="text-gray-400 hover:text-gray-600">
                    <Info className="w-4 h-4" />
                  </button>
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  Скидки по оборудованию и расходным материалам рассчитываются динамически по шкале дилера в зависимости от фактического объёма за период.
                </TooltipContent>
              </Tooltip>
              <div className="ml-auto no-print">
                <Button size="sm" variant="outline" onClick={handlePrint}>
                  <Printer className="size-4 mr-1" /> Печать
                </Button>
              </div>
            </div>
            <CardDescription>
              РФ: за {quarter} кв. ({quarterMonthRange}) • Заруб: за {quarter <= 2 ? "1" : "2"} п/г ({halfYearMonthRange}) 2026 ф.г.
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollableTable firstColWidth="220px" maxHeight="70vh">
                <TableHeader className="sticky top-0 z-10 bg-card">
                  <TableRow>
                    <TableHead className="sticky left-0 z-[2] bg-card min-w-[180px] font-medium text-xs whitespace-nowrap">Дилер</TableHead>
                    <TableHead className="text-center text-xs whitespace-nowrap">Тип</TableHead>
                    <TableHead className="text-right text-xs whitespace-nowrap">План</TableHead>
                    <TableHead className="text-right text-xs whitespace-nowrap">Факт</TableHead>
                    <TableHead className="text-center text-xs whitespace-nowrap">Вып.</TableHead>
                    <TableHead className="text-right text-xs whitespace-nowrap">Об. план</TableHead>
                    <TableHead className="text-right text-xs whitespace-nowrap">Об. факт</TableHead>
                    <TableHead className="text-right text-xs whitespace-nowrap">РМ план</TableHead>
                    <TableHead className="text-right text-xs whitespace-nowrap">РМ факт</TableHead>
                    <TableHead className="text-right bg-emerald-50 text-xs whitespace-nowrap">Об.%</TableHead>
                    <TableHead className="text-right bg-emerald-50 text-xs whitespace-nowrap">РМ%</TableHead>
                    <TableHead className="text-center text-xs whitespace-nowrap no-print">Печать</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {dealers.map((d) => {
                    const plan = quarterlyPlan(d, quarter);
                    const facts = quarterlyFactsByCategory(d, quarter);
                    const hasFact = hasFacts([
                      ...d.facts.service.months, ...d.facts.equipment.months, ...d.facts.materials.months,
                    ]);
                    const factTotal = hasFact
                      ? (facts.service ?? 0) + (facts.equipment ?? 0) + (facts.materials ?? 0)
                      : null;
                    const execPct = factTotal === null || plan === 0 ? null : Math.round((factTotal / plan) * 100);
                    const eqPlan = d.type === "Заруб" ? d.plan.equipment / 2 : d.plan.equipment / 4;
                    const matPlan = d.type === "Заруб" ? d.plan.materials / 2 : d.plan.materials / 4;
                    const eqPct = calcEquipmentDiscountPct(d, quarter);
                    const matPct = calcMaterialsDiscountPct(d, quarter);
                    const noData = factTotal === null;
                    return (
                      <TableRow
                        key={d.id}
                        className={`border-b transition-colors hover:bg-emerald-50/50 ${noData ? "opacity-60" : ""}`}
                      >
                        <TableCell className="sticky left-0 z-[2] bg-white font-medium text-xs whitespace-nowrap">{d.name}</TableCell>
                        <TableCell className="text-center whitespace-nowrap">
                          {d.type === "РФ" ? (
                            <Badge variant="default" className="text-[10px] px-1.5 py-0">РФ</Badge>
                          ) : (
                            <Badge variant="secondary" className="text-[10px] px-1.5 py-0">Заруб</Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right tabular-nums text-xs whitespace-nowrap">{fmt(plan)} / {periodSuffix(d)}</TableCell>
                        <TableCell className="text-right tabular-nums text-xs whitespace-nowrap">
                          {factTotal === null ? "нет" : `${fmt(factTotal)} / ${periodSuffix(d)}`}
                        </TableCell>
                        <TableCell className="text-center tabular-nums text-xs font-medium whitespace-nowrap">
                          {execPct === null ? "—" : `${execPct}%`}
                        </TableCell>
                        <TableCell className="text-right tabular-nums text-xs text-gray-600 whitespace-nowrap">{fmt(Math.round(eqPlan), "€")}</TableCell>
                        <TableCell className="text-right tabular-nums text-xs whitespace-nowrap">{fmt(facts.equipment, "€")}</TableCell>
                        <TableCell className="text-right tabular-nums text-xs text-gray-600 whitespace-nowrap">{fmt(Math.round(matPlan), "€")}</TableCell>
                        <TableCell className="text-right tabular-nums text-xs whitespace-nowrap">{fmt(facts.materials, "€")}</TableCell>
                        <TableCell className="text-right tabular-nums text-xs font-semibold text-emerald-700 bg-emerald-50 whitespace-nowrap">
                          {eqPct === null ? "—" : fmtPct(eqPct)}
                        </TableCell>
                        <TableCell className="text-right tabular-nums text-xs font-semibold text-emerald-700 bg-emerald-50 whitespace-nowrap">
                          {matPct === null ? "—" : fmtPct(matPct)}
                        </TableCell>
                        <TableCell className="text-center whitespace-nowrap no-print">
                          <button
                            type="button"
                            onClick={() => handleDealerPrint(d)}
                            className="inline-flex items-center justify-center w-7 h-7 rounded-md text-gray-500 hover:bg-emerald-100 hover:text-emerald-700 transition-colors"
                            title={`Печать карточки: ${d.name}`}
                          >
                            <Printer className="size-3.5" />
                          </button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
            </ScrollableTable>
          </CardContent>
        </Card>

        {/* ─── Table 2: Service ───────────────────────────────────────────── */}
        <Card className="overflow-hidden">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <CardTitle className="font-semibold text-base">Скидка по Сервису — накопительно</CardTitle>
              <Tooltip>
                <TooltipTrigger asChild>
                  <button type="button" className="text-violet-500 hover:text-violet-600">
                    <Info className="w-4 h-4" />
                  </button>
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  Скидка по сервису рассчитывается по шкале «Сервис (ЗЧ) — абсолютные отгрузки за 12 месяцев» от накопленного факта.
                </TooltipContent>
              </Tooltip>
            </div>
            <CardDescription>Накопительным итогом за расчётный период</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollableTable firstColWidth="180px" maxHeight="60vh">
                <TableHeader className="sticky top-0 z-10 bg-card">
                  <TableRow>
                    <TableHead className="sticky left-0 z-[2] bg-card min-w-[160px] font-medium text-xs whitespace-nowrap">Дилер</TableHead>
                    <TableHead className="text-center text-xs whitespace-nowrap">Тип</TableHead>
                    <TableHead className="text-right text-xs whitespace-nowrap">План Сервис (год)</TableHead>
                    <TableHead className="text-right text-xs whitespace-nowrap">Факт Сервис (накопл.)</TableHead>
                    <TableHead className="text-center text-xs whitespace-nowrap">Выполн. Сервис</TableHead>
                    <TableHead className="text-right bg-violet-50 text-xs whitespace-nowrap">Сервис %</TableHead>
                    <TableHead className="text-center text-xs whitespace-nowrap no-print">Печать</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {dealers.map((d) => {
                    const sp = servicePlan(d);
                    const sf = serviceFactAccumulated(d);
                    const exec = sf === null ? null : sp === 0 ? null : Math.round((sf / sp) * 100);
                    const pct = getServiceDiscountPctNormalized(d, quarter);
                    const noData = sf === null;
                    return (
                      <TableRow
                        key={d.id}
                        className={`border-b transition-colors hover:bg-violet-50/50 ${noData ? "opacity-60" : ""}`}
                      >
                        <TableCell className="sticky left-0 z-[2] bg-white font-medium text-xs whitespace-nowrap">{d.name}</TableCell>
                        <TableCell className="text-center whitespace-nowrap">
                          {d.type === "РФ" ? (
                            <Badge variant="default" className="text-[10px] px-1.5 py-0">РФ</Badge>
                          ) : (
                            <Badge variant="secondary" className="text-[10px] px-1.5 py-0">Заруб</Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right tabular-nums text-xs whitespace-nowrap">{fmt(sp)}</TableCell>
                        <TableCell className="text-right tabular-nums text-xs whitespace-nowrap">
                          {sf === null ? "нет" : fmt(sf)}
                        </TableCell>
                        <TableCell className="text-center tabular-nums text-xs font-medium whitespace-nowrap">
                          {exec === null ? "—" : `${exec}%`}
                        </TableCell>
                        <TableCell className="text-right tabular-nums text-xs font-bold text-violet-800 bg-violet-50 whitespace-nowrap">
                          {pct === null ? "—" : fmtPct(pct)}
                        </TableCell>
                        <TableCell className="text-center whitespace-nowrap no-print">
                          <button
                            type="button"
                            onClick={() => handleDealerPrint(d)}
                            className="inline-flex items-center justify-center w-7 h-7 rounded-md text-gray-500 hover:bg-violet-100 hover:text-violet-700 transition-colors"
                            title={`Печать карточки: ${d.name}`}
                          >
                            <Printer className="size-3.5" />
                          </button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
            </ScrollableTable>
          </CardContent>
        </Card>
      </div>
    </TooltipProvider>
  );
}
