"use client";

import { useState, useMemo } from "react";
import type { DealerData, Quarter, ScaleTable } from "@/lib/types";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Building2, CheckCircle2 } from "lucide-react";
import {
  parseTier, findScaleTable, calcEquipmentDiscountPct, calcMaterialsDiscountPct,
  getServiceDiscountPctNormalized,
} from "@/lib/discount";
import { quarterlyFactsByCategory, serviceFactAccumulated } from "@/lib/calc";

interface Props {
  scales: ScaleTable[];
  dealers: DealerData[];
  quarter: Quarter;
}

export function ScalesTab({ scales, dealers, quarter }: Props) {
  const [selectedDealerId, setSelectedDealerId] = useState(dealers[0]?.id ?? "");
  const selectedDealer = dealers.find((d) => d.id === selectedDealerId) ?? dealers[0];

  // Determine which tier column is active for the selected dealer, per scale table.
  const activeTierByScale = useMemo(() => {
    const result = new Map<string, number>(); // scaleTitle → column index
    if (!selectedDealer) return result;
    for (const table of scales) {
      const lcTitle = table.title.toLowerCase();
      let volume: number | null = null;
      if (lcTitle.includes("оборудование")) {
        const f = quarterlyFactsByCategory(selectedDealer, quarter);
        volume = f.equipment !== null ? f.equipment / 1000 : null;
      } else if (lcTitle.includes("расходные")) {
        const f = quarterlyFactsByCategory(selectedDealer, quarter);
        volume = f.materials !== null ? f.materials / 1000 : null;
      } else if (lcTitle.includes("сервис")) {
        const f = serviceFactAccumulated(selectedDealer);
        volume = f;
      }
      if (volume === null) continue;
      // Find matching column
      for (let i = 0; i < table.columns.length; i++) {
        const t = parseTier(table.columns[i]);
        const min = t.min ?? -Infinity;
        const max = t.max ?? Infinity;
        if (volume >= min && volume <= max) {
          result.set(table.title, i);
          break;
        }
      }
    }
    return result;
  }, [scales, selectedDealer, quarter]);

  // Summary of computed discounts for the selected dealer
  const discounts = useMemo(() => {
    if (!selectedDealer) return null;
    return {
      equipment: calcEquipmentDiscountPct(selectedDealer, quarter),
      materials: calcMaterialsDiscountPct(selectedDealer, quarter),
      service: getServiceDiscountPctNormalized(selectedDealer, quarter),
    };
  }, [selectedDealer, quarter]);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="font-semibold text-base">Шкалы скидок</CardTitle>
          <CardDescription>
            Выберите дилера, чтобы увидеть активный тир в каждой шкале. Расчёт обновляется автоматически.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap items-center gap-3">
            <Building2 className="size-5 text-emerald-600" />
            <div className="flex-1 min-w-[200px]">
              <label className="text-xs text-gray-500 font-medium block mb-1">
                Выберите дилера для подсветки активного тира
              </label>
              <Select value={selectedDealerId} onValueChange={setSelectedDealerId}>
                <SelectTrigger className="w-full sm:w-[320px]"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {dealers.map((d) => (
                    <SelectItem key={d.id} value={d.id}>
                      {d.name} ({d.type})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {discounts && (
              <div className="flex flex-wrap gap-2 ml-auto">
                {discounts.equipment !== null && (
                  <div className="px-3 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200">
                    <div className="text-xs text-emerald-600 font-medium">Оборуд.</div>
                    <div className="text-sm font-bold text-emerald-700">{discounts.equipment.toFixed(1)}%</div>
                  </div>
                )}
                {discounts.materials !== null && (
                  <div className="px-3 py-1.5 rounded-lg bg-sky-50 border border-sky-200">
                    <div className="text-xs text-sky-600 font-medium">Расх. мат.</div>
                    <div className="text-sm font-bold text-sky-700">{discounts.materials.toFixed(1)}%</div>
                  </div>
                )}
                {discounts.service !== null && (
                  <div className="px-3 py-1.5 rounded-lg bg-violet-50 border border-violet-200">
                    <div className="text-xs text-violet-600 font-medium">Сервис</div>
                    <div className="text-sm font-bold text-violet-700">{discounts.service.toFixed(1)}%</div>
                  </div>
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        {scales.map((table) => {
          const activeCol = activeTierByScale.get(table.title);
          return (
            <Card key={table.title} className="overflow-hidden">
              <CardHeader className="pb-3">
                <CardTitle className="font-semibold text-base">{table.title}</CardTitle>
                {table.period && (
                  <CardDescription>{table.period}</CardDescription>
                )}
              </CardHeader>
              <CardContent className="p-0">
                <div className="w-full overflow-auto thin-scroll" style={{ maxHeight: "50vh" }}>
                  <style>{`
                    .thin-scroll::-webkit-scrollbar { width: 10px; height: 10px; }
                    .thin-scroll::-webkit-scrollbar-track { background: #f1f5f9; }
                    .thin-scroll::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 4px; }
                    .thin-scroll::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
                    .thin-scroll * { scrollbar-width: thin; scrollbar-color: #cbd5e1 #f1f5f9; }
                  `}</style>
                  <div style={{ minWidth: "520px" }}>
                    <Table>
                      <TableHeader className="sticky top-0 z-10 bg-card">
                        <TableRow>
                          <TableHead className="min-w-[200px] text-xs whitespace-nowrap">Компонент</TableHead>
                          {table.columns.map((c, i) => (
                            <TableHead
                              key={c}
                              className={`text-center text-xs whitespace-nowrap ${
                                activeCol === i
                                  ? "bg-emerald-100 text-emerald-700 font-bold"
                                  : ""
                              }`}
                            >
                              {c}
                              {activeCol === i && (
                                <CheckCircle2 className="inline-block size-3 ml-1 text-emerald-600" />
                              )}
                            </TableHead>
                          ))}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {table.rows.map((row) => (
                          <TableRow
                            key={row.component}
                            className={row.isTotal ? "bg-emerald-50/50 font-semibold" : undefined}
                          >
                            <TableCell className={`${row.isTotal ? "font-semibold text-gray-900 text-xs" : "text-gray-700 text-xs"} whitespace-nowrap`}>
                              {row.component}
                            </TableCell>
                            {row.values.map((v, i) => (
                              <TableCell
                                key={i}
                                className={`text-center tabular-nums text-xs whitespace-nowrap ${
                                  activeCol === i
                                    ? "bg-emerald-50 font-semibold text-emerald-700"
                                    : row.isTotal
                                      ? "font-semibold"
                                      : ""
                                }`}
                              >
                                {v}
                              </TableCell>
                            ))}
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {selectedDealer && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="font-semibold text-base">
              Расчёт для {selectedDealer.name} ({selectedDealer.type}) — {quarter} кв.
            </CardTitle>
            <CardDescription>
              Тир определяется по факту отгрузок за {selectedDealer.type === "Заруб" ? "полугодие" : "квартал"} (для оборудования и расходных материалов)
              {" "}или за 12 месяцев (для сервиса). Активный тир подсвечивается зелёным в каждой таблице.
            </CardDescription>
          </CardHeader>
        </Card>
      )}
    </div>
  );
}
