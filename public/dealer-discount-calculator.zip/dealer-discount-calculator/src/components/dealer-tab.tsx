"use client";

import { useState, useEffect } from "react";
import type { DealerData } from "@/lib/types";
import { MONTH_LABELS, fmt, sumYear } from "@/lib/calc";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Printer } from "lucide-react";
import { printDealer } from "@/components/dealer-print-view";

interface Props {
  dealers: DealerData[];
  quarter: 1 | 2 | 3 | 4;
  quarterMonthRange: string;
}

export function DealerTab({ dealers, quarter, quarterMonthRange }: Props) {
  const rfDealers = dealers.filter((d) => d.type === "РФ");
  const foreignDealers = dealers.filter((d) => d.type === "Заруб");
  const [selectedId, setSelectedId] = useState(dealers[0]?.id ?? "");

  // Pick up externally-set selected dealer (from "go to dealer" button in summary tab)
  useEffect(() => {
    if (typeof window !== "undefined") {
      const w = window as unknown as { __selectedDealer?: string };
      if (w.__selectedDealer && dealers.some((d) => d.id === w.__selectedDealer)) {
        setSelectedId(w.__selectedDealer);
        delete w.__selectedDealer;
      }
    }
  }, [dealers]);

  const dealer = dealers.find((d) => d.id === selectedId) ?? dealers[0];

  if (!dealer) {
    return <div className="text-muted-foreground p-4">Нет дилеров. Добавьте нового на вкладке «Сводная».</div>;
  }

  const rows = [
    { label: "Сервис", months: dealer.facts.service.months },
    { label: "Оборудование", months: dealer.facts.equipment.months },
    { label: "Расход. мат.", months: dealer.facts.materials.months },
  ];

  // Opens a dedicated print window with the dealer's detailed card (reference design)
  const handleDealerPrint = () =>
    printDealer({ dealer, quarter, quarterMonthRange });

  // Quarterly sums for visual emphasis
  const quarterSum = (months: (number | null)[], q: 1 | 2 | 3 | 4) => {
    const start = (q - 1) * 3;
    const slice = months.slice(start, start + 3);
    if (!slice.some((v) => v !== null)) return null;
    return slice.reduce<number>((a, b) => a + (b ?? 0), 0);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <Select value={selectedId} onValueChange={setSelectedId}>
          <SelectTrigger className="w-[260px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectGroup>
              <SelectLabel>Российские дилеры</SelectLabel>
              {rfDealers.map((d) => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
            </SelectGroup>
            <SelectGroup>
              <SelectLabel>Зарубежные дилеры</SelectLabel>
              {foreignDealers.map((d) => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
            </SelectGroup>
          </SelectContent>
        </Select>
        <Badge variant={dealer.type === "РФ" ? "default" : "secondary"}>{dealer.type}</Badge>
        <Button variant="outline" size="sm" onClick={handleDealerPrint} className="ml-auto">
          <Printer className="size-4 mr-1" /> Печать
        </Button>
      </div>

      <Card className="overflow-hidden">
        <CardHeader className="pb-3">
          <CardTitle className="font-semibold text-base">{dealer.name} — помесячные отгрузки</CardTitle>
          <CardDescription>
            Финансовый год начинается в апреле. Пустые месяцы отображаются как «—». Сумма за квартал выделена цветом.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <div className="w-full overflow-auto thin-scroll" style={{ maxHeight: "60vh" }}>
            <style>{`
              .thin-scroll::-webkit-scrollbar { width: 10px; height: 10px; }
              .thin-scroll::-webkit-scrollbar-track { background: #f1f5f9; }
              .thin-scroll::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 4px; }
              .thin-scroll::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
              .thin-scroll * { scrollbar-width: thin; scrollbar-color: #cbd5e1 #f1f5f9; }
            `}</style>
            <div style={{ minWidth: "1080px" }}>
              <Table>
                <TableHeader className="sticky top-0 z-10 bg-card">
                  <TableRow>
                    <TableHead className="min-w-[120px] text-xs whitespace-nowrap">Кат.</TableHead>
                    {MONTH_LABELS.map((m, i) => (
                      <TableHead
                        key={m}
                        className={`text-center min-w-[80px] text-xs whitespace-nowrap ${
                          i % 3 === 0 ? "border-l border-gray-200 bg-gray-50/50" : ""
                        }`}
                      >
                        {m}
                      </TableHead>
                    ))}
                    <TableHead className="text-center border-l border-gray-200 bg-gray-50/50 text-xs whitespace-nowrap">Год</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.map(({ label, months }) => {
                    const year = sumYear(months);
                    return (
                      <TableRow key={label}>
                        <TableCell className="font-medium text-xs whitespace-nowrap">{label}</TableCell>
                        {months.map((v, i) => (
                          <TableCell
                            key={i}
                            className={`text-center tabular-nums text-xs whitespace-nowrap ${
                              i % 3 === 0 ? "border-l border-gray-200 bg-gray-50/30" : ""
                            }`}
                          >
                            {v === null ? "—" : fmt(v)}
                          </TableCell>
                        ))}
                        <TableCell className="text-center font-semibold tabular-nums text-xs border-l border-gray-200 bg-gray-50/30 whitespace-nowrap">
                          {fmt(year)}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="overflow-hidden">
        <CardHeader className="pb-3">
          <CardTitle className="font-semibold text-base">Квартальные итоги</CardTitle>
          <CardDescription>Суммы по каждому кварталу финансового года</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <div className="w-full overflow-auto thin-scroll">
            <div style={{ minWidth: "720px" }}>
              <Table>
                <TableHeader className="sticky top-0 z-10 bg-card">
                  <TableRow>
                    <TableHead className="min-w-[120px] text-xs whitespace-nowrap">Кат.</TableHead>
                    <TableHead className="text-right text-xs whitespace-nowrap">Q1 (апр–июн)</TableHead>
                    <TableHead className="text-right text-xs whitespace-nowrap">Q2 (июл–сен)</TableHead>
                    <TableHead className="text-right text-xs whitespace-nowrap">Q3 (окт–дек)</TableHead>
                    <TableHead className="text-right text-xs whitespace-nowrap">Q4 (янв–мар)</TableHead>
                    <TableHead className="text-right text-xs whitespace-nowrap">1 п/г</TableHead>
                    <TableHead className="text-right text-xs whitespace-nowrap">2 п/г</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.map(({ label, months }) => {
                    const q1 = quarterSum(months, 1);
                    const q2 = quarterSum(months, 2);
                    const q3 = quarterSum(months, 3);
                    const q4 = quarterSum(months, 4);
                    const h1 = (q1 ?? 0) + (q2 ?? 0);
                    const h2 = (q3 ?? 0) + (q4 ?? 0);
                    return (
                      <TableRow key={label}>
                        <TableCell className="font-medium text-xs whitespace-nowrap">{label}</TableCell>
                        <TableCell className="text-right tabular-nums text-xs whitespace-nowrap">{fmt(q1)}</TableCell>
                        <TableCell className="text-right tabular-nums text-xs whitespace-nowrap">{fmt(q2)}</TableCell>
                        <TableCell className="text-right tabular-nums text-xs whitespace-nowrap">{fmt(q3)}</TableCell>
                        <TableCell className="text-right tabular-nums text-xs whitespace-nowrap">{fmt(q4)}</TableCell>
                        <TableCell className="text-right tabular-nums text-xs font-medium bg-gray-50/50 whitespace-nowrap">
                          {(q1 === null && q2 === null) ? "—" : fmt(h1)}
                        </TableCell>
                        <TableCell className="text-right tabular-nums text-xs font-medium bg-gray-50/50 whitespace-nowrap">
                          {(q3 === null && q4 === null) ? "—" : fmt(h2)}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
