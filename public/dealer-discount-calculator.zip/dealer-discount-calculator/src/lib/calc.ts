import type { DealerData, Quarter } from "./types";

/** Financial year month labels (Apr..Mar). */
export const MONTH_LABELS = [
  "Апр", "Май", "Июн", "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек", "Янв", "Фев", "Мар",
] as const;

/** Sums the 12 monthly fact values into an annual total. Returns `null` if all months are null. */
export function sumYear(values: (number | null)[]): number | null {
  const filtered = values.filter((v): v is number => v !== null);
  if (filtered.length === 0) return null;
  return filtered.reduce((a, b) => a + b, 0);
}

/** Sums the months belonging to a specific quarter. Q1=Apr..Jun (idx 0..2), Q2=Jul..Sep, etc. */
export function sumQuarter(values: (number | null)[], q: Quarter): number | null {
  const start = (q - 1) * 3;
  const slice = values.slice(start, start + 3);
  return sumYear(slice);
}

/** "нет данных" if all values are null */
export function hasFacts(values: (number | null)[]): boolean {
  return values.some((v) => v !== null);
}

/** Quarterly plan based on annual plan / 4 (for РФ) or annual / 2 (for Заруб — half-year) */
export function quarterlyPlan(dealer: DealerData, q: Quarter): number {
  const annual = dealer.plan.equipment + dealer.plan.materials + dealer.plan.service;
  if (dealer.type === "Заруб") {
    // Зарубежные dealers report half-year totals (/пг) — Q1+Q2 = H1, Q3+Q4 = H2
    // For display purposes, we show /пг total per quarter as half-year
    return Math.round(annual / 2);
  }
  return Math.round(annual / 4);
}

/** Quarterly fact split by category, returns [service, equipment, materials] */
export function quarterlyFactsByCategory(
  dealer: DealerData,
  q: Quarter,
): { service: number | null; equipment: number | null; materials: number | null } {
  const months = q === 1 ? [0, 1, 2] : q === 2 ? [3, 4, 5] : q === 3 ? [6, 7, 8] : [9, 10, 11];
  const pick = (arr: (number | null)[]) => {
    const slice = months.map((i) => arr[i]);
    if (!hasFacts(slice)) return null;
    return slice.reduce<number>((a, b) => a + (b ?? 0), 0);
  };
  return {
    service: pick(dealer.facts.service.months),
    equipment: pick(dealer.facts.equipment.months),
    materials: pick(dealer.facts.materials.months),
  };
}

/** Service plan — same as plan.service (annual). Service % is custom per dealer or default 14% */
export function servicePlan(dealer: DealerData): number {
  return dealer.plan.service;
}

/** Accumulated service fact (YTD) — sum of all months with data */
export function serviceFactAccumulated(dealer: DealerData): number | null {
  return sumYear(dealer.facts.service.months);
}

/** Format: 1234567 -> "1 234 567". Decimals preserved with comma (ru-RU convention). */
export function fmt(n: number | null | undefined, suffix = ""): string {
  if (n === null || n === undefined) return "—";
  // Use non-breaking space as thousands separator, comma as decimal separator (ru-RU convention)
  // Round to integer if the value is "effectively integer" (no real fractional part needed for currency display)
  const rounded = Math.round(n);
  // If the original value differs from rounded by less than 1, show integer (cleaner display for EUR plans)
  if (Math.abs(n - rounded) < 0.01) {
    return rounded.toLocaleString("ru-RU").replace(/\u00A0/g, " ") + suffix;
  }
  // Otherwise show 2 decimal places
  return n.toLocaleString("ru-RU", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).replace(/\u00A0/g, " ") + suffix;
}

/** Format percent: 14 -> "14.0%" */
export function fmtPct(n: number | null | undefined, digits = 1): string {
  if (n === null || n === undefined) return "—";
  return `${n.toFixed(digits)}%`;
}

/** Execution: fact / plan as percent, 0..100 */
export function execution(fact: number | null, plan: number): string {
  if (fact === null) return "—";
  if (plan === 0) return "—";
  return `${Math.round((fact / plan) * 100)}%`;
}

// MONTH_LABELS is already exported above as `const … = […]`.
